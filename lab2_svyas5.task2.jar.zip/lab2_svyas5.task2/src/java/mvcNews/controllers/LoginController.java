package mvcNews.controllers;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.Bean.RoleBean;
import mvcNews.services.UserService;
import mvcNews.services.UserServiceFactory;

 
//import sun.text.normalizer.ICUBinary.Authenticate;
 
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	public LoginController() {
		super();
	}
 
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
 
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");
		
		HttpSession session = request.getSession();
		if(session != null) {
			session.setAttribute("uname", username);
			session.setAttribute("pwd", password);
			request.setAttribute("uname", username);
		}
		
		Cookie lab2cookieUname = new Cookie("uname", username);
		response.addCookie(lab2cookieUname);
		
		RoleBean rb = new RoleBean();
		rb.setUsername(username);
		rb.setPassword(password);
		/*
		RoleDAO rdao = new RoleDAO();
		String temp = rdao.authenticateUser(rb);
		*/
		UserService us = null;
		us = UserServiceFactory.getInstance();
		String temp = us.checkUpdateUser(username, rb);
		
		
		if(temp.equals("newEntry")) {
			response.sendRedirect("role.jsp");
		}
		else if(temp.equals("wrongPassword")) {
			response.sendRedirect("error.jsp");
		}
		else {
			session.setAttribute("role", temp);
			request.setAttribute("role", temp);
			if(temp.equals("Subscriber")) {
				request.getRequestDispatcher("Subscriber").forward(request, response);
			}
			else {
				request.getRequestDispatcher("Reporter").forward(request, response);
			}
		}
	}
 
}