package mvcNews.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.Bean.NewsBean;
import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;

/**
 * Servlet implementation class NewStoryController
 */

public class NewStoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public NewStoryController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//String id = request.getParameter("storyid");
		String title = request.getParameter("storytitle");
		String author = null;
		HttpSession session = request.getSession(false);
		if(session != null)
			author = (String)session.getAttribute("uname");
		String content = request.getParameter("storycontent");
		String access = request.getParameter("storyAccess");
		
		if(session != null) {
			//session.setAttribute("newStoryId", id);
			session.setAttribute("newStoryTitle", title);
			session.setAttribute("newStoryContent", content);
			session.setAttribute("newStoryAccess", access);
		}
		
		NewsBean nb = new NewsBean();
		nb.setTitle(title);
		nb.setStoryContent(content);
		nb.setAuthor(author);
		nb.setAccess(access);
		nb.setSubscriberList(null);
		/*
		NewsDAO nd = new NewsDAO();
		nd.createNewStory(nb);
		*/
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		ns.createNewStory(title, nb);
		
		//request.setAttribute("message", "New Story Added Succesfully!");
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
