package mvcNews.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.Bean.RoleBean;
import mvcNews.services.UserService;
import mvcNews.services.UserServiceFactory;

/**
 * Servlet implementation class RoleController
 */
public class RoleController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RoleController() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String role = request.getParameter("role");
		String username = null;
		String password = null;

		HttpSession session = request.getSession();
		if(session != null)
		{
			username = (String) session.getAttribute("uname");
			password = (String) session.getAttribute("pwd");
			session.setAttribute("role", role);
			request.setAttribute("role", role);
		}
		
		RoleBean rb = new RoleBean();
		rb.setUsername(username);
		rb.setPassword(password);
		rb.setRole(role);
		
		UserService us = null;
		us=UserServiceFactory.getInstance();
		us.populateUser(username, rb);
		/*
		RoleDAO rdao = new RoleDAO();
		rdao.assignRole(rb);
		*/
		if(role.equals("Subscriber")) {
			request.getRequestDispatcher("Subscriber").forward(request, response);
		}
		else {
			request.getRequestDispatcher("Reporter").forward(request, response);
		}
	}

}
