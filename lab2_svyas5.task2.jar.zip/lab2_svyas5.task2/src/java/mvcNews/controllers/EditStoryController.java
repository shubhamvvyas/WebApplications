package mvcNews.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.Bean.NewsBean;
import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;

/**
 * Servlet implementation class EditStoryController
 */

public class EditStoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditStoryController() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("storyTitleEdit");
		String author = null;
		HttpSession session = request.getSession(false);
		if(session != null)
			author = (String)session.getAttribute("uname");
		String content = request.getParameter("storyContentEdit");
		String access = request.getParameter("storyAccessEdit");
		
		if(session != null) {
			//session.setAttribute("newStoryId", id);
			session.setAttribute("editStoryTitle", title);
			session.setAttribute("editStoryContent", content);
			session.setAttribute("editStoryAccess", access);
		}
		
		NewsBean nb = new NewsBean();
		nb.setTitle(title);
		nb.setStoryContent(content);
		nb.setAuthor(author);
		nb.setAccess(access);
		//nb.setSubscriberList(null);
		
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		ns.editStory((String)session.getAttribute("oldTitle"), nb);
		/*
		NewsDAO nd = new NewsDAO();
		nd.editStory((String)session.getAttribute("oldTitle"), nb);
		*/
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
