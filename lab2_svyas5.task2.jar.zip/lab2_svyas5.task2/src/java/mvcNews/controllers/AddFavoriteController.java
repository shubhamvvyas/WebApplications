package mvcNews.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;

/**
 * Servlet implementation class AddFavoriteController
 */

public class AddFavoriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public AddFavoriteController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if(session != null) {
			String uname = session.getAttribute("uname").toString();
			String title = session.getAttribute("favoriteStoryTitle").toString();
			
			NewsService ns = null;
			ns = NewsServiceFactory.getInstance();
			ns.addStoryAsFavorite(title, uname);
			
		}
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
