package mvcNews.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import mvcNews.Bean.RoleBean;
import mvcNews.services.UserService;

public class UserDataMap implements UserService {
	private static LinkedHashMap<String, RoleBean> hm = new LinkedHashMap<String, RoleBean>();

	@SuppressWarnings("rawtypes")
	public String checkUpdateUser(String username, RoleBean rb) {
		/*
		if(hm == null) {
			System.out.println(username);
			hm = new HashMap<String, RoleBean>();
		}
		 */
		if(!hm.containsKey(username)) {
			return "newEntry";
		}
		else {
			Iterator it = hm.entrySet().iterator();
			while(it.hasNext()) {
				HashMap.Entry pair = (HashMap.Entry)it.next();
				if(pair.getKey().toString().equals(username)) {
					RoleBean rb1 = (RoleBean) pair.getValue();
					if(rb1.getPassword().equals(rb.getPassword())) {
						return rb1.getRole();
					}
					else
						return "wrongPassword";
				}
				it.remove();
			}
		}
		return "newEntry";
	}

	public void populateUser(String username, RoleBean rb) {
		if(hm != null) {
			hm.put(username, rb);
		}
	}
}
