package mvcNews.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;

import mvcNews.Bean.NewsBean;
import mvcNews.services.NewsService;

public class NewsDataMap implements NewsService {
	private static LinkedHashMap<String, NewsBean> hm;

	public void createNewStory(String title, NewsBean nb) {
		if(hm == null) {
			hm = new LinkedHashMap<String, NewsBean>();
		}
		if(hm != null) {
			hm.put(title, nb);
		}
	}

	@SuppressWarnings("rawtypes")
	public ArrayList<String> sendPublicStories(){
		if(hm == null) {
			hm = new LinkedHashMap<String, NewsBean>();
		}
		ArrayList<String> al1 = new ArrayList<String>();
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			NewsBean nb = (NewsBean) pair.getValue();
			if(nb.getAccess().equals("Public")) {
				al1.add(nb.getTitle());
			}
		}
		return al1;
	}

	@SuppressWarnings("rawtypes")
	public String sendStoryContent(String title) {
		String temp = null;
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			NewsBean nb = (NewsBean) pair.getValue();
			if(nb.getTitle().equals(title)) {
				temp = nb.getStoryContent();
			}
		}
		return temp;
	}

	@SuppressWarnings("rawtypes")
	public ArrayList<String> sendAllStories(String subscriber){
		if(hm == null) {
			hm = new LinkedHashMap<String, NewsBean>();
		}
		boolean flag = false;
		ArrayList<String> al1 = new ArrayList<String>();
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			NewsBean nb = (NewsBean) pair.getValue();
			HashSet<String> hs2 = null;
			hs2 = nb.getSubscriberList();
			if(hs2 != null)
			{
				for(String s : hs2) {
					if(s.equals(subscriber)) {
						al1.add(nb.getTitle());
						break;
					}
				}
			}
		}
		Iterator it1 = hm.entrySet().iterator();
		while(it1.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it1.next();
			NewsBean nb = (NewsBean) pair.getValue();
			if(!al1.isEmpty()) {
				for(String s : al1) {
					if(s.equals(nb.getTitle())) {
						flag = true;
						break;
					}
					else {
						flag = false;
					}
				}
			}
			if(flag == false) {
				al1.add(nb.getTitle());
			}
		}
		return al1;
	}

	@SuppressWarnings("rawtypes")
	public void addStoryAsFavorite(String title, String subscriber) {
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			NewsBean nb = (NewsBean) pair.getValue();
			if(nb.getTitle().equals(title)) {
				if(nb.getSubscriberList() == null) {
					HashSet<String> hs1 = new HashSet<String>();
					nb.setSubscriberList(hs1);
				}
				nb.getSubscriberList().add(subscriber);
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public LinkedHashMap<String, Boolean> sendReporterStories(String reporter){
		if(hm == null) {
			hm = new LinkedHashMap<String, NewsBean>();
		}
		LinkedHashMap<String, Boolean> lhm1 = new LinkedHashMap<String, Boolean>();
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			NewsBean nb = (NewsBean) pair.getValue();
			if(nb.getAccess().equals("Public")) {
				if(nb.getAuthor().equals(reporter)) {
					lhm1.put(nb.getTitle(), true);
				}
				else {
					lhm1.put(nb.getTitle(), false);
				}
			}
			else if(nb.getAccess().equals("Subscribers Only")) {
				if(nb.getAuthor().equals(reporter)) {
					lhm1.put(nb.getTitle(), true);
				}
			}
		}
		return lhm1;
	}
	
	@SuppressWarnings("rawtypes")
	public NewsBean editObjectSender(String title) {
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			if(pair.getKey().equals(title)) {
				return (NewsBean) pair.getValue();
			}
		}
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public void editStory(String oldTitle, NewsBean nb) {
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry)it.next();
			if(pair.getKey().equals(oldTitle)) {
				NewsBean nb1 = (NewsBean) pair.getValue();
				HashSet<String> hs1 = nb1.getSubscriberList();
				if(hs1 != null) {
					nb.setSubscriberList(hs1);
				}
				hm.remove(pair.getKey());
				break;
			}
		}
		hm.put(nb.getTitle(), nb);
	}
	
	@SuppressWarnings("rawtypes")
	public void deleteStory(String title) {
		Iterator it = hm.entrySet().iterator();
		while(it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry) it.next();
			if(pair.getKey().equals(title)) {
				hm.remove(pair.getKey());
			}
		}
	}
}
