package mvcNews.model;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import mvcNews.Bean.RoleBean;
import mvcNews.services.UserService;

public class UserDataMongo implements UserService {

	private MongoClient client;

	@SuppressWarnings("deprecation")
	public String checkUpdateUser(String username, RoleBean rb) {

		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("Users");

		if(col.findOne(username) == null) {
			client.close();
			return "newEntry";
		}
		else {
			DBCursor cursor = col.find();
			while(cursor.hasNext()) {
				DBObject o = cursor.next();
				String uname = (String) o.get("_id");
				String pword = (String) o.get("password");
				String role = (String) o.get("role");
				if(uname.equals(username)) {
					if(pword.equals(rb.getPassword())) 
						return role;
					else
						return "wrongPassword";
				}
			}
		}
		client.close();
		return "newEntry";
	}

	@SuppressWarnings("deprecation")
	public void populateUser(String username, RoleBean rb) {
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("Users");

		BasicDBObject document = new BasicDBObject();
		document.put("_id", username);
		document.put("password", rb.getPassword());
		document.put("role", rb.getRole());

		col.insert(document);
		client.close();

	}

	public MongoClient connectDB() {
		MongoClient tempClient = new MongoClient("localhost", 27017);
		return tempClient;
	}

}
