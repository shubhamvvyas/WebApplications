package mvcNews.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import mvcNews.Bean.NewsBean;
import mvcNews.services.NewsService;

public class NewsDataMongo implements NewsService {
	private MongoClient client;
	public MongoClient connectDB() {
		MongoClient tempClient = new MongoClient("localhost", 27017);
		return tempClient;
	}

	@SuppressWarnings("deprecation")
	public void createNewStory(String title, NewsBean nb) {
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		BasicDBObject document = new BasicDBObject();
		document.put("_id", title);
		document.put("author", nb.getAuthor());
		document.put("access", nb.getAccess());
		document.put("content", nb.getStoryContent());
		HashSet<String> hs1 = new HashSet<String>();
		document.put("subscriberList", hs1);

		col.insert(document);
		client.close();

	}

	@SuppressWarnings("deprecation")
	public ArrayList<String> sendPublicStories(){
		ArrayList<String> al1 = new ArrayList<String>();
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");

		DBCursor cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			String access = (String) o.get("access");
			if(access.equals("Public")) {
				al1.add((String) o.get("_id"));
			}
		}

		client.close();
		return al1;
	}

	@SuppressWarnings("deprecation")
	public String sendStoryContent(String title) {
		String temp = null;
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBObject dbo1 = col.findOne(title);
		temp = (String) dbo1.get("content");
		client.close();
		return temp;
	}

	@SuppressWarnings({ "deprecation" })
	public ArrayList<String> sendAllStories(String subscriber){
		boolean flag = false;
		ArrayList<String> al1 = new ArrayList<String>();
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBCursor cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			BasicDBList bdl = (BasicDBList) o.get("subscriberList");
			HashSet<String> hs2 = new HashSet<String>();
			for(Object o1 : bdl) {
				hs2.add((String)o1);
			}
			if(hs2 != null)
			{
				for(String s : hs2) {
					if(s.equals(subscriber)) {
						al1.add((String)o.get("_id"));
						break;
					}
				}
			}
		}
		cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			if(!al1.isEmpty()) {
				for(String s : al1) {
					if(s.equals((String)o.get("_id"))) {
						flag = true;
						break;
					}
					else {
						flag = false;
					}
				}
			}
			if(flag == false) {
				al1.add((String)o.get("_id"));
			}
		}
		client.close();
		return al1;
	}

	@SuppressWarnings("deprecation")
	public void addStoryAsFavorite(String title, String subscriber) {
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBCursor cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			String temp = (String) o.get("_id");
			if(temp.equals(title)) {
				BasicDBObject updateFields = new BasicDBObject();
				updateFields.append("subscriberList", subscriber);
				BasicDBObject setQuery = new BasicDBObject();
				setQuery.append("$addToSet", updateFields);
				col.update(o,setQuery);
			}
		}
		client.close();
	}

	@SuppressWarnings("deprecation")
	public LinkedHashMap<String, Boolean> sendReporterStories(String reporter){
		LinkedHashMap<String, Boolean> lhm1 = new LinkedHashMap<String, Boolean>();
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBCursor cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			if(o.get("access").toString().equals("Public")) {
				if(o.get("author").equals(reporter)) {
					lhm1.put((String)o.get("_id"), true);
				}
				else {
					lhm1.put((String)o.get("_id"), false);
				}
			}
			else if(o.get("access").toString().equals("Subscribers Only")) {
				if(o.get("author").equals(reporter)) {
					lhm1.put((String)o.get("_id"), true);
				}
			}
		}
		client.close();
		return lhm1;
	}

	@SuppressWarnings("deprecation")
	public NewsBean editObjectSender(String title) {
		NewsBean nb = new NewsBean();
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBObject o = col.findOne(title);
		nb.setTitle(title);
		nb.setAuthor(o.get("author").toString());
		nb.setStoryContent(o.get("content").toString());
		nb.setAccess(o.get("access").toString());
		client.close();
		return nb;
	}

	@SuppressWarnings("deprecation")
	public void editStory(String oldTitle, NewsBean nb) {
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBCursor cursor = col.find();
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			if(o.get("_id").toString().equals(oldTitle)){
				BasicDBList bdl = (BasicDBList) o.get("subscriberList");
				HashSet<String> hs2 = new HashSet<String>();
				for(Object o1 : bdl) {
					hs2.add((String)o1);
				}
				if(hs2 != null) {
					nb.setSubscriberList(hs2);
				}
				col.remove(o);
				break;
			}
		}
		BasicDBObject document = new BasicDBObject();
		document.put("_id", nb.getTitle());
		document.put("author", nb.getAuthor());
		document.put("access", nb.getAccess());
		document.put("content", nb.getStoryContent());
		document.put("subscriberList", nb.getSubscriberList());

		col.insert(document);
		client.close();
	}
	
	@SuppressWarnings("deprecation")
	public void deleteStory(String title) {
		client = connectDB();
		DB db = client.getDB("lab2");
		DBCollection col = db.getCollection("NewsStories");
		DBObject o = col.findOne(title);
		col.remove(o);
		client.close();
	}
}
