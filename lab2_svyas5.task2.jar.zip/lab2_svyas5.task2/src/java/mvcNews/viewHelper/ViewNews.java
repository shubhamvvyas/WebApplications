package mvcNews.viewHelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;


public class ViewNews extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ViewNews() {
		super();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<body>");
		out.println("<h1 style=\"text-align: center\">Welcome to NEW News Inc.</h1>");
		out.println("<div style=\"text-align: right\">Want to Explore More?&emsp;");
		out.println("<a href=\"login.jsp\">Login!</a></div>");
		out.println("<br/><br/>");
		out.println("<center>");
		
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		ArrayList<String> al1 = ns.sendPublicStories();
		//NewsDAO nd = new NewsDAO();
		//ArrayList<String> al1 = nd.getPublicStories();
		
		if(al1 != null) {
			for(String s : al1) {
				out.println("<table>");
				out.println("<tr><td><a href=\"DisplayContent?"+s+"\">"+s+"</a></td></tr>");
				out.println("</table>");
			}
		}
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
