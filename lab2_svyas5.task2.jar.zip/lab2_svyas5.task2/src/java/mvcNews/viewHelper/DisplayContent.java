package mvcNews.viewHelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;


public class DisplayContent extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DisplayContent() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		//response.setCharacterEncoding("UTF-8");
		String queryString = request.getQueryString();
		queryString = URLDecoder.decode(queryString, "UTF-8");
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<body>");
		out.println("<div align=\"right\">");
		String role = null;
		HttpSession session = request.getSession(false);
		if(session != null) {
			role = session.getAttribute("role").toString();
			session.setAttribute("favoriteStoryTitle", queryString);
			if(role.equals("Subscriber")) {
				out.println("<form action=\"AddFavoriteController\" method=\"post\">");
				out.println("<input type=\"submit\" value=\"Add to Favorites\"></input>");
				out.println("</form>");
			}
		}
		out.println("<center>");
		out.println("<h1>"+queryString+"</h1>");
		
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		String content = ns.sendStoryContent(queryString);
		
		//NewsDAO nd = new NewsDAO();
		//String content = nd.getStoryContent(queryString);
		
		out.println("<br/><br/>");
		
		out.println(content+"</center>");
		out.println("<br/><br/>");
		if(role == null)
			out.println("<center><a href=\"ViewNews\">Go Back!</a><center>");
		else if(role.equals("Reporter")){
			out.println("<center><a href=\"Reporter\">Go Back!</a></center>");
		}
		else if(role.equals("Subscriber")){
			out.println("<center><a href=\"Subscriber\">Go Back!</a></center>");
		}
		out.println("</body>");
		out.println("</html>");
	}

}
