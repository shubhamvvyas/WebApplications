package mvcNews.viewHelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;

public class Subscriber extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Subscriber() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Subscriber Page</title>");            
        out.println("</head>");
        out.println("<body>");
        out.println("<center>");
        HttpSession session = request.getSession(false);
		if(session != null) {
			out.println("<h1>Welcome "+session.getAttribute("uname").toString());
			out.println(", "+session.getAttribute("role").toString()+"</h1>");
		}
		out.println("<br/><br/>");
		out.println("<center>");
		String subscriber = (String) session.getAttribute("uname");
		
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		ArrayList<String> al1 = ns.sendAllStories(subscriber);
		//NewsDAO nd = new NewsDAO();
		//ArrayList<String> al1 = nd.getAllStoriesForSubscribers(subscriber);
		
		
		if(al1 != null) {
			for(String s : al1) {
				out.println("<table>");
				out.println("<tr><td><a href=\"DisplayContent?"+s+"\">"+s+"</a></td></tr>");
				out.println("</table>");
			}
		}
		out.println("</center>");
		out.println("<a href=\"LogoutController\">Logout</a>");
		out.println("<center>");
		out.println("</body>");
        out.println("</html>");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

}
