package mvcNews.viewHelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcNews.services.NewsService;
import mvcNews.services.NewsServiceFactory;

public class Reporter extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Reporter() {
		super();
	}
	@SuppressWarnings("rawtypes")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Reporter Page</title>");            
		out.println("</head>");
		out.println("<body>");
		out.println("<center>");
		HttpSession session = request.getSession(false);
		if(session != null) {
			out.println("<h1>Welcome "+session.getAttribute("uname").toString());
			out.println(", "+session.getAttribute("role").toString()+"</h1>");
		}
		out.println("<div align=\"right\"><a href=\"addStory.jsp\">Create a Story</a></div>");
		out.println("<br/><br/>");
		//out.println("<br/><br/>");
		out.println("<center>");
		String reporter = (String) session.getAttribute("uname");
		
		NewsService ns = null;
		ns = NewsServiceFactory.getInstance();
		LinkedHashMap<String, Boolean> al1 = ns.sendReporterStories(reporter);
		
		//NewsDAO nd = new NewsDAO();
		//LinkedHashMap<String, Boolean> al1 = nd.getAllStoriesForReporter(subscriber);
		
		if(al1 != null) {
			Iterator it = al1.entrySet().iterator();
			while(it.hasNext()) {
				HashMap.Entry pair = (HashMap.Entry)it.next();
				boolean flag = (boolean) pair.getValue();
				if(flag) {
					out.println("<table>");
					out.println("<tr><td><a href=\"DisplayContent?"+
							(String)pair.getKey()+"\">"+(String)pair.getKey()+"</a></td>");
					out.println("<td><a href=\"editStory.jsp?"+
							(String)pair.getKey()+"\">Edit</td>");
					out.println("<td><a href=\"deleteConfirm.jsp?"+
							(String)pair.getKey()+"\">Delete</td>");
					out.println("</table>");
				}
				else {
					out.println("<table>");
					out.println("<tr><td><a href=\"DisplayContent?"+
							(String)pair.getKey()+"\">"+(String)pair.getKey()+"</a></td></tr></table>");
				}
			}
		}
		out.println("<a href=\"LogoutController\">Logout</a>");
		out.println("<center>");
		out.println("</body>");
		out.println("</html>");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

}
