package mvcNews.services;


import java.util.Properties;



public class NewsServiceFactory {

	private NewsServiceFactory() {

	}

	public static NewsService getInstance() {

		if (_newsService != null) {
			return _newsService;
		}

		return null;
	}

	private static NewsService _newsService;

	static {
		try {
			Properties dbProperties = new Properties();
			Class<?> initClass = null;
			dbProperties.load(NewsServiceFactory.class.getClassLoader().getResourceAsStream("newNews.properties"));
			String serviceImpl = dbProperties.getProperty("newsServiceImpl");
			if (serviceImpl != null) {
				initClass = Class.forName(serviceImpl);
			}
			else
				initClass = Class.forName("mvcNews.model.NewsDataMap");//default
			_newsService = (NewsService)initClass.newInstance();
		} catch (Throwable t) {
			t.printStackTrace();
		} finally {
		}
	}

}
