package mvcNews.services;

import mvcNews.Bean.RoleBean;

public interface UserService {
	public String checkUpdateUser(String username, RoleBean rb);
	public void populateUser(String username, RoleBean rb);
}
