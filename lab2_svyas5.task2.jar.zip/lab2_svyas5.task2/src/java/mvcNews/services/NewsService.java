package mvcNews.services;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import mvcNews.Bean.NewsBean;

public interface NewsService {
	public void createNewStory(String title, NewsBean nb);
	public ArrayList<String> sendPublicStories();
	public String sendStoryContent(String title);
	public ArrayList<String> sendAllStories(String subscriber);
	public void addStoryAsFavorite(String title, String subscriber);
	public LinkedHashMap<String, Boolean> sendReporterStories(String reporter);
	public NewsBean editObjectSender(String title);
	public void editStory(String oldTitle, NewsBean nb);
	public void deleteStory(String title);
}
