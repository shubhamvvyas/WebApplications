package mvcNews.services;


import java.util.Properties;



public class UserServiceFactory {
	private UserServiceFactory() {

	}

	public static UserService getInstance() {
		if (_userService != null)
			return _userService;

		return null;
	}

	private static UserService _userService = null;

	static {
		try {
			Properties dbProperties = new Properties();
			Class<?> initClass = null;
			dbProperties.load(NewsServiceFactory.class.getClassLoader().getResourceAsStream("newNews.properties"));
			String serviceImpl = dbProperties.getProperty("userServiceImpl");
			if (serviceImpl != null) {
				initClass = Class.forName(serviceImpl);
			}
			else
				initClass = Class.forName("mvcNews.model.UserDataMap");//default
			_userService = (UserService)initClass.newInstance();
		} catch (Throwable t) {
			t.printStackTrace();
		} finally {
		}
	}
}
