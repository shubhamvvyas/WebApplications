package mvcNews.Bean;

import java.util.HashSet;

public class NewsBean {
	private String title;
	private String author;
	private String access;
	private String storyContent;
	private HashSet<String> subscriberList = null;
	
	public HashSet<String> getSubscriberList() {
		return subscriberList;
	}
	public void setSubscriberList(HashSet<String> subscriberList) {
		this.subscriberList = subscriberList;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public String getStoryContent() {
		return storyContent;
	}
	public void setStoryContent(String storyContent) {
		this.storyContent = storyContent;
	}
	
}
