newNews.properties has two properties. One for user and one for news stories.
As of now, I have given the value for in memory implementation(if it is not able to read from properties file,
even then it would implement Map functionality). There is no password for connecting to mongoDB
 Default values are "localhost" and port no is 27017. If mongoDB is installed on the system, it should be able to
connect. I have included two 'json' files, for user and news story collcetions. There is no fixed schema, however,
username in 'Users' collection and title in 'NewsStories' collection are the unique '_id' for mongoDB.
If you want to swicth implementation to DB, just change 'mvcNews.model.UserDataMap' and 'mvcNews.model.NewsDataMap'
in newNews.properties file under properties directory to 'mvcNews.model.UserDataMongo' and 'mvcNews.model.NewsDataMongo'
respectively.
The name of the database used was lab2
Users Collection
_id->username
password->password
role->role

NewsStories Collection
_id->title
author->reporter who created the story
access->access
content->story content
subscriberList->subscribers who have added the story as 'favorite'.