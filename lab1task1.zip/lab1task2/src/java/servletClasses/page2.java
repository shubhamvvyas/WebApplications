/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubhamvvyas
 */
public class page2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            
            if(fname != null &&  lname != null){
                HttpSession session = request.getSession();
                if(session != null)
                {
                    session.setAttribute("fname", fname);
                    session.setAttribute("lname", lname);
                    Cookie lab1cookieFname = new Cookie("lab1Cookiefname", fname);
                    Cookie lab1cookieLname = new Cookie("lab1Cookielname", lname);
        
                    response.addCookie(lab1cookieFname);
                    response.addCookie(lab1cookieLname);
                }
            }
            
            
            
            Cookie[] cplangs = request.getCookies();
            
            Cookie c = null;
            
            boolean cflag = false;
            boolean cppflag = false;
            boolean jflag = false;
            boolean pyflag = false;
            boolean sflag = false;
            boolean pflag = false;
            
            if(cplangs != null){
                for(int i = 0; i < cplangs.length; i++){
                    if(cplangs[i].getValue().equals("C")){
                        cflag = true;
                    }
                    else if(cplangs[i].getValue().equals("CPP")){
                        cppflag = true;
                    }
                    else if(cplangs[i].getValue().equals("Java")){
                        jflag = true;
                    }
                    else if(cplangs[i].getValue().equals("Python")){
                        pyflag = true;
                    }
                    else if(cplangs[i].getValue().equals("Scheme")){
                        sflag = true;
                    }
                    else if(cplangs[i].getValue().equals("Prolog")){
                        pflag = true;
                    }
                }
            }
            
            
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet page2</title>");            
            out.println("</head>");
            out.println("<body>");
            //out.println("<h1>Servlet page2 at " + request.getContextPath() + "</h1>");
            out.println("<form method=\"post\" action=\"page3\">");
            out.println("<fieldset>");
            out.println("<table border=\"0\">");
            out.println("<tr><td>Programming Languages Known:</td>");
            if(cflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"C\" checked>C</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"C\">C</td>");
            if(cppflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"CPP\" checked>C++</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"CPP\">C++</td>");
            if(jflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Java\" checked>Java</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Java\">Java</td>");
            if(pyflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Python\" checked>Python</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Python\">Python</td>");
            if(sflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Scheme\" checked>Scheme</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Scheme\">Scheme</td>");
            if(pflag)
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Prolog\" checked>Prolog</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"plang\" value=\"Prolog\">Prolog</td>");
            out.println("</tr><tr><td><input type=\"submit\" value=\"Next\"></td></tr><table>");
            out.println("</fieldset></form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
