/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubhamvvyas
 */
public class page4 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String days[] =  request.getParameterValues("day");
            Cookie[] lab1CookieDay = new Cookie[7];
            if(days != null){
                HttpSession session = request.getSession();
                if(session != null)
                {
                    for(int i = 0; i < days.length; i++){
                    if(days[i].equals("M")){
                    session.setAttribute("daym", days[i]);
                    lab1CookieDay[0] = new Cookie("lab1CookieDaym", days[i]);
                    response.addCookie(lab1CookieDay[0]);
                }
                else if(days[i].equals("T")){
                    session.setAttribute("dayt", days[i]);
                    lab1CookieDay[1] = new Cookie("lab1CookieDayt", days[i]);
                    response.addCookie(lab1CookieDay[1]);
                }
                else if(days[i].equals("W")){
                    session.setAttribute("dayw", days[i]);
                    lab1CookieDay[2] = new Cookie("lab1CookieDayw", days[i]);
                    response.addCookie(lab1CookieDay[2]);
                }
                else if(days[i].equals("Th")){
                    session.setAttribute("dayth", days[i]);
                    lab1CookieDay[3] = new Cookie("lab1CookieDayth", days[i]);
                    response.addCookie(lab1CookieDay[3]);
                }
                else if(days[i].equals("F")){
                    session.setAttribute("dayf", days[i]);
                    lab1CookieDay[4] = new Cookie("lab1CookieDayf", days[i]);
                    response.addCookie(lab1CookieDay[4]);
                }
                else if(days[i].equals("S")){
                    session.setAttribute("days", days[i]);
                    lab1CookieDay[5] = new Cookie("lab1CookieDays", days[i]);
                    response.addCookie(lab1CookieDay[5]);
                }
		else if(days[i].equals("Su")){
                    session.setAttribute("daysu", days[i]);
                    lab1CookieDay[6] = new Cookie("lab1CookieDaysu", days[i]);
                    response.addCookie(lab1CookieDay[6]);
                }
                }
                }
            }
            
            
            Cookie[] cdest = request.getCookies();
            
            Cookie c = null;
            
            boolean mflag = false;
            boolean kflag = false;
            boolean lflag = false;
            boolean cflag = false;
            
            if(cdest != null){
                for(int i = 0; i < cdest.length; i++){
                    if(cdest[i].getValue().equals("Maldives")){
                        mflag = true;
                    }
                    else if(cdest[i].getValue().equals("Kashmir")){
                        kflag = true;
                    }
                    else if(cdest[i].getValue().equals("LasVegas")){
                        lflag = true;
                    }
                    else if(cdest[i].getValue().equals("CostaRica")){
                        cflag = true;
                    }
                }
            }
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet page4</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<form method=\"post\" action=\"page5\">");
            out.println("<fieldset>");
            out.println("<table border=\"0\">");
            out.println("<tr><td>"+
                        "Favourite Holiday Destination:"+
                        "</td>");
            if(mflag)
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"Maldives\" checked>Maldives</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"Maldives\">Maldives</td>");
            if(kflag)
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"Kashmir\" checked>Kashmir</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"Kashmir\">Kashmir</td>");
            if(lflag)
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"LasVegas\" checked>Las Vegas</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"LasVegas\">Las Vegas</td>");
            if(cflag)
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"CostaRica\" checked>Costa Rica</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"dest\" value=\"CostaRica\">Costa Rica</td>");
            
            out.println("</tr>"+
                    "<tr>"+
                        "<td><input type=\"submit\" value=\"Next\"></td>"+
                    "</tr>");
            out.println("</table></fieldset></form></body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
