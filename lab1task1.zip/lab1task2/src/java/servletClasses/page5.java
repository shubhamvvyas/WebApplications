/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubhamvvyas
 */
public class page5 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String dest[] =  request.getParameterValues("dest");
            Cookie lab1CookieDest[] = new Cookie[4];
            if(dest != null){
                HttpSession session = request.getSession();
                if(session != null)
                {
                for(int i = 0; i < dest.length; i++){
                    if(dest[i].equals("Maldives")){
                    session.setAttribute("destm", dest[i]);
                    lab1CookieDest[0] = new Cookie("lab1CookieDestm", dest[i]);
                    response.addCookie(lab1CookieDest[0]);
                }
                else if(dest[i].equals("Kashmir")){
                    session.setAttribute("destk", dest[i]);
                    lab1CookieDest[1] = new Cookie("lab1CookieDestk", dest[i]);
                    response.addCookie(lab1CookieDest[1]);
                }
                else if(dest[i].equals("LasVegas")){
                    session.setAttribute("destl", dest[i]);
                    lab1CookieDest[2] = new Cookie("lab1CookieDestl", dest[i]);
                    response.addCookie(lab1CookieDest[2]);
                }
                else if(dest[i].equals("CostaRica")){
                    session.setAttribute("destc", dest[i]);
                    lab1CookieDest[3] = new Cookie("lab1CookieDestc", dest[i]);
                    response.addCookie(lab1CookieDest[3]);
                }
                }
                }
            }
            
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet page5</title>");            
            out.println("</head>");
            out.println("<body>");
            HttpSession session = request.getSession(false);
            if(session != null){
                out.println("First Name: "+session.getAttribute("fname").toString());
                out.println("<br/>");
                out.println("Last Name: "+session.getAttribute("lname").toString());
                out.println("<br/>");
                out.println("Programming languages: ");
                if(session.getAttribute("plangc").toString() != null)
                    out.println(session.getAttribute("plangc").toString()+" ");
                if(session.getAttribute("plangcpp").toString() != null)
                    out.println("C++");
                if(session.getAttribute("plangj").toString() != null)
                    out.println(session.getAttribute("plangj").toString()+" ");
                if(session.getAttribute("plangpy").toString() != null)
                    out.println(session.getAttribute("plangpy").toString()+" ");
                if(session.getAttribute("plangs").toString() != null)
                    out.println(session.getAttribute("plangs").toString()+" ");
                if(session.getAttribute("plangp").toString() != null)
                    out.println(session.getAttribute("plangp").toString()+" ");
                out.println("<br/>");
                out.println("Days Available: ");
                if(session.getAttribute("daym").toString() != null)
                    out.println(session.getAttribute("daym").toString()+" ");
                if(session.getAttribute("dayt").toString() != null)
                    out.println(session.getAttribute("dayt").toString()+" ");
                if(session.getAttribute("dayw").toString() != null)
                    out.println(session.getAttribute("dayw").toString()+" ");
                if(session.getAttribute("dayth").toString() != null)
                    out.println(session.getAttribute("dayth").toString()+" ");
                if(session.getAttribute("dayf").toString() != null)
                    out.println(session.getAttribute("dayf").toString()+" ");
                if(session.getAttribute("days").toString() != null)
                    out.println(session.getAttribute("days").toString()+" ");
                if(session.getAttribute("daysu").toString() != null)
                    out.println(session.getAttribute("daysu").toString()+" ");
                out.println("<br/>");
                out.println("Favourite Holiday Destination: ");
                if(session.getAttribute("destm").toString() != null)
                    out.println(session.getAttribute("destm").toString()+" ");
                if(session.getAttribute("destk").toString() != null)
                    out.println(session.getAttribute("destk").toString()+" ");
                if(session.getAttribute("destl").toString() != null)
                    out.println(session.getAttribute("destl").toString()+" ");
                if(session.getAttribute("destc").toString() != null)
                    out.println(session.getAttribute("destc").toString()+" ");
                session.invalidate();
                
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
