/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubhamvvyas
 */
public class page3 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String plang[] =  request.getParameterValues("plang");
            Cookie[] lab1CookiePlang = new Cookie[6];
            if(plang != null){
                HttpSession session = request.getSession();
                if(session != null){
                for(int i = 0; i < plang.length; i++){
                    if(plang[i].equals("C")){
                    session.setAttribute("plangc", plang[i]);
                    lab1CookiePlang[0] = new Cookie("lab1Cookieplangc", plang[i]);
                    response.addCookie(lab1CookiePlang[0]);
                    
                }
                    else if(plang[i].equals("CPP")){
                    session.setAttribute("plangcpp", plang[i]);
                    lab1CookiePlang[1] = new Cookie("lab1Cookieplangcpp", plang[i]);
                    response.addCookie(lab1CookiePlang[1]);
                }
                    else if(plang[i].equals("Java")){
                    session.setAttribute("plangj", plang[i]);
                    lab1CookiePlang[2] = new Cookie("lab1Cookieplangj", plang[i]);
                    response.addCookie(lab1CookiePlang[2]);
                    
                }
                    else if(plang[i].equals("Python")){
                    session.setAttribute("plangpy", plang[i]);
                    lab1CookiePlang[3] = new Cookie("lab1Cookieplangpy", plang[i]);
                    response.addCookie(lab1CookiePlang[3]);
                }
                    else if(plang[i].equals("Scheme")){
                    session.setAttribute("plangs", plang[i]);
                    lab1CookiePlang[4] = new Cookie("lab1Cookieplangs", plang[i]);
                    response.addCookie(lab1CookiePlang[4]);
                }
                    else if(plang[i].equals("Prolog")){
                    session.setAttribute("plangp", plang[i]);
                    lab1CookiePlang[5] = new Cookie("lab1Cookieplangp", plang[i]);
                    response.addCookie(lab1CookiePlang[5]);
                }
                }
                }
            }
            
            
            Cookie[] cdays = request.getCookies();
            
            Cookie c = null;
            
            boolean mflag = false;
            boolean tflag = false;
            boolean wflag = false;
            boolean thflag = false;
            boolean fflag = false;
            boolean sflag = false;
            boolean suflag = false;
            
            if(cdays != null){
                for(int i = 0; i < cdays.length; i++){
                    if(cdays[i].getValue().equals("M")){
                        mflag = true;
                    }
                    else if(cdays[i].getValue().equals("T")){
                        tflag = true;
                    }
                    else if(cdays[i].getValue().equals("W")){
                        wflag = true;
                    }
                    else if(cdays[i].getValue().equals("Th")){
                        thflag = true;
                    }
                    else if(cdays[i].getValue().equals("F")){
                        fflag = true;
                    }
                    else if(cdays[i].getValue().equals("S")){
                        sflag = true;
                    }
					else if(cdays[i].getValue().equals("Su")){
                        suflag = true;
                    }
                }
            }
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet page3</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<form method=\"post\" action=\"page4\">");
            out.println("<fieldset>");
            out.println("<table border=\"0\">");
            out.println("<tr><td>"
                        +"Available days during the week:"+
                        "</td>");
            if(mflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"M\" checked>Monday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"M\">Monday</td>");
            if(tflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"T\" checked>Tuesday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"T\">Tuesday</td>");
            if(wflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"W\" checked>Wednesday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"W\">Wednesday</td>");
            if(thflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"Th\" checked>Thursday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"Th\">Thursday</td>");
            if(fflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"F\" checked>Friday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"F\">Friday</td>");
            if(sflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"S\" checked>Saturday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"S\">Saturday</td>");
            if(suflag)
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"Su\" checked>Sunday</td>");
            else
                out.println("<td><input type=\"checkbox\" name=\"day\" value=\"Su\">Sunday</td>");
                
            out.println("</tr><tr><td><input type=\"submit\" value=\"Next\"></td></tr>");
            out.println("</table></fieldset></form></body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
