/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author shubhamvvyas
 */
public class getpersons extends HttpServlet {
    
    
    private HashSet<String> set = new HashSet<String>();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParserConfigurationException, SAXException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String userAgent = request.getHeader("user-agent");
            if(userAgent.contains("Chrome")){
                out.println("<body style='background-color:#00FFFF;'>");
            }
            StringBuffer requestURL = request.getRequestURL();
            String queryString = request.getQueryString();
            
            
            DocumentBuilderFactory documentBuilderFactory = 
                DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder =
                        documentBuilderFactory.newDocumentBuilder();
                Document doc = documentBuilder.parse("dataXML.xml");
                Element root = doc.getDocumentElement();
                root.normalize();
            
            if (queryString == null) {
                
                NodeList rootChildren = root.getChildNodes();
                for(int i = 0; i < rootChildren.getLength(); i++){
                    NodeList subRootChildren = rootChildren.item(i).getChildNodes();
                    out.println((i+1)+".\t");
                    out.println(subRootChildren.item(0).getTextContent()+" "
                    +subRootChildren.item(1).getTextContent()+",");
                    NodeList plang = subRootChildren.item(2).getChildNodes();
                    for(int k = 0; k < plang.getLength(); k++){
                        if(plang.item(k).getTextContent().equals("CPP")){
                            out.println(" C++");
                        }
                        else
                            out.println(" "+plang.item(k).getTextContent());
                    }
                    out.println(",");
                    NodeList week = subRootChildren.item(3).getChildNodes();
                    for(int j = 0; j < week.getLength(); j++){
                        String s = week.item(j).getTextContent();
                        switch(s){
                            case "M" : out.println("Monday"); break;
                            case "T" : out.println("Tuesday"); break;
                            case "W" : out.println("Wednesday"); break;
                            case "Th" : out.println("Thursday"); break;
                            case "F" : out.println("Friday"); break;
                            case "S" : out.println("Saturday"); break;
                            case "Su" : out.println("Sunday"); break;
                        }
                    }
                    out.println(",");
                    NodeList dest = subRootChildren.item(4).getChildNodes();
                    for(int k = 0; k < dest.getLength(); k++){
                        out.println(" "+dest.item(k).getTextContent());
                    }
                    /*
                    for(int j = 2; j < subRootChildren.getLength(); j++){
                        NodeList temp = subRootChildren.item(j).getChildNodes();
                        for(int k = 0; k < temp.getLength(); k++){
                            out.println(" "+temp.item(k).getTextContent());
                        }
                        if(j != subRootChildren.getLength()-1)
                            out.println(",");
                    }*/
                    out.println("<html><br/><br/></html>");
                }
            }
            else{
                String[] queryArray1 = queryString.split("&");
                
                for(String s : queryArray1){
                    String[] nameValueArray = s.split("=");
                    if(nameValueArray[0].equals("fname") || 
                            nameValueArray[0].equals("lname") ||
                            nameValueArray[0].equals("plang") ||
                            nameValueArray[0].equals("day") ||
                            nameValueArray[0].equals("dest")){
                        buildStringFromXML(nameValueArray[1], response);
                    }
                    else{
                        out.println("Invalid URL!");
                    }
                }
                int count = 1;
                for(String s : set){
                    out.println(count+".\t");
                    out.println(s);
                    out.println("<html><br/><br/></html>");
                    count++;
                }
            }
            /*
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet getpersons</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet getpersons at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        }
    }
    
    public void buildStringFromXML(String str,
            HttpServletResponse response) 
            throws ParserConfigurationException, SAXException, IOException{
        PrintWriter out = response.getWriter();
        String[] attr = str.split("\\+");
        
        DocumentBuilderFactory documentBuilderFactory = 
                DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder =
                        documentBuilderFactory.newDocumentBuilder();
        Document doc = documentBuilder.parse("dataXML.xml");
        Element root = doc.getDocumentElement();
        root.normalize();
        NodeList rootFNames = root.getElementsByTagName("FirstName");
        NodeList rootLNames = root.getElementsByTagName("LastName");
        NodeList rootLangs = root.getElementsByTagName("PL");
        NodeList rootDays = root.getElementsByTagName("Day");
        NodeList rootDest = root.getElementsByTagName("Destination");
        for(String s : attr){
            
            for(int i = 0; i < rootFNames.getLength(); i++){
                if(s.equals(rootFNames.item(i).getTextContent())){
                    Node n1 = root.getChildNodes().item(i);
                    appendBuilder(doc, n1);
                }
            }
            for(int i = 0; i < rootLNames.getLength(); i++){
                if(s.equals(rootLNames.item(i).getTextContent())){
                    Node n1 = root.getChildNodes().item(i);
                    appendBuilder(doc, n1);
                }
            }
            for(int i = 0; i < rootLangs.getLength(); i++){
                if(s.equals(rootLangs.item(i).getTextContent())){
                    Node n1 = rootLangs.item(i).getParentNode().getParentNode();
                    appendBuilder(doc, n1);
                }
            }
            for(int i = 0; i < rootDays.getLength(); i++){
                if(s.equals(rootDays.item(i).getTextContent())){
                    Node n1 = rootDays.item(i).getParentNode().getParentNode();
                    appendBuilder(doc, n1);
                }
            }
            for(int i = 0; i < rootDest.getLength(); i++){
                if(s.equals(rootDest.item(i).getTextContent())){
                    Node n1 = rootDest.item(i).getParentNode().getParentNode();
                    appendBuilder(doc, n1);
                }
            }
        }
    }
    
    public void appendBuilder(Document doc, Node n1){
        StringBuilder comp = new StringBuilder();
        comp.append(n1.getChildNodes().item(0).getTextContent()).append(" ");
        comp.append(n1.getChildNodes().item(1).getTextContent()).append(",");
        NodeList plangs = n1.getChildNodes().item(2).getChildNodes();
        for(int i = 0; i < plangs.getLength(); i++){
            if(plangs.item(i).getTextContent().equals("CPP")){
                comp.append(" C++");
            }
            else
                comp.append(" ").append(plangs.item(i).getTextContent());
        }
        comp.append(",");
        NodeList days = n1.getChildNodes().item(3).getChildNodes();
        for(int i = 0; i < days.getLength(); i++){
            String s = days.item(i).getTextContent();
                        switch(s){
                            case "M" : comp.append(" Monday"); break;
                            case "T" : comp.append(" Tuesday"); break;
                            case "W" : comp.append(" Wednesday"); break;
                            case "Th" : comp.append(" Thursday"); break;
                            case "F" : comp.append(" Friday"); break;
                            case "S" : comp.append(" Saturday"); break;
                            case "Su" : comp.append(" Sunday"); break;
                        }
        }
        comp.append(",");
        NodeList dest = n1.getChildNodes().item(4).getChildNodes();
        for(int i = 0; i < dest.getLength(); i++){
            comp.append(" ").append(dest.item(i).getTextContent());
        }
        if(!set.contains(comp.toString())){
            set.add(comp.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParserConfigurationException | SAXException ex) {
            Logger.getLogger(getpersons.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParserConfigurationException | SAXException ex) {
            Logger.getLogger(getpersons.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
