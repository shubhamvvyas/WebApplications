/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servletClasses;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

/**
 *
 * @author shubhamvvyas
 */
@WebServlet(name = "newperson", urlPatterns = {"/newperson"})
public class newperson extends HttpServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private static int count;
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String plang[] =  request.getParameterValues("plang");
        String weekAvail[] = request.getParameterValues("day");
        String dest[] = request.getParameterValues("dest");
        String referrer = request.getHeader("referer");
        try {
            
            createUpdateXML(fname, lname, plang, weekAvail, dest);
        } catch (Exception ex) {
            Logger.getLogger(newperson.class.getName()).log(Level.SEVERE, 
                    null, ex);
        }
        
        
        Cookie lab1cookieFname = new Cookie("fname", fname);
        Cookie lab1cookieLname = new Cookie("lname", lname);
        
        lab1cookieFname.setMaxAge(365 * 24 * 60 * 60);
        lab1cookieLname.setMaxAge(365 * 24 * 60 * 60);
        
        response.addCookie(lab1cookieFname);
        response.addCookie(lab1cookieLname);
        
        //request.setAttribute(fname, lab1cookieFname.toString());
        //request.setAttribute(lname, lab1cookieLname.toString());
        
        
        if(fname != null && lname != null){
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Transaction was successful!</h1><br/>");
            DocumentBuilderFactory documentBuilderFactory = 
                DocumentBuilderFactory.newInstance();
            try {
                DocumentBuilder documentBuilder =
                        documentBuilderFactory.newDocumentBuilder();
                Document doc = documentBuilder.parse("dataXML.xml");
                Element root = doc.getDocumentElement();
                out.println(root.getChildNodes().getLength()+"\n");
            } catch (ParserConfigurationException | SAXException ex) {
                Logger.getLogger(newperson.class.getName()).log(Level.SEVERE, null, ex);
            }
            out.println("<br/><br/><a href=" + referrer + ">Back</a>");
        }
        else{
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Transaction failed!</h1>");
        }
    }
    public void createUpdateXML(String fname, String lname, String[] plang, 
            String[] weekAvail, String[] dest) 
            throws Exception{
        DocumentBuilderFactory documentBuilderFactory = 
                DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = 
                documentBuilderFactory.newDocumentBuilder();
        
        File f = new File("dataXML.xml");
        Document doc;
        Element root;
        if(!(f.exists()))
        {
            doc = documentBuilder.newDocument();
            root = doc.createElement("Users");
            doc.appendChild(root);
        }
        else{
            doc = documentBuilder.parse("dataXML.xml");
            root = doc.getDocumentElement();
        }
        
        if(checkEntry(fname, lname, doc)){
            
        Element subRoot = doc.createElement("User");
        root.appendChild(subRoot);
        
        Element child1 = doc.createElement("FirstName");
        subRoot.appendChild(child1);
        Text text = doc.createTextNode(fname);
        child1.appendChild(text);
        
        Element child2 = doc.createElement("LastName");
        subRoot.appendChild(child2);
        Text text1 = doc.createTextNode(lname);
        child2.appendChild(text1);
        
        Element child3 = doc.createElement("PLanguages");
        subRoot.appendChild(child3);
        for(String s : plang){
            Element e = doc.createElement("PL");
            Text textPlang = doc.createTextNode(s);
            e.appendChild(textPlang);
            child3.appendChild(e);
        }
        
        Element child4 = doc.createElement("AvailableDays");
        subRoot.appendChild(child4);
        for(String s : weekAvail){
            Element e = doc.createElement("Day");
            Text textAvail = doc.createTextNode(s);
            e.appendChild(textAvail);
            child4.appendChild(e);
        }
        
        Element child5 = doc.createElement("Holiday");
        subRoot.appendChild(child5);
        for(String s : dest){
            Element e = doc.createElement("Destination");
            Text textAvail = doc.createTextNode(s);
            e.appendChild(textAvail);
            child5.appendChild(e);
        }
        
        DOMSource source = new DOMSource(doc);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        StreamResult result = new StreamResult(f);
        transformer.transform(source, result);
        }
        else{
            replaceValues(fname, lname, plang, weekAvail, dest, doc);
        }
        }
    
    public boolean checkEntry(String fname, String lname, Document doc
    ) throws IOException{
        Element root = doc.getDocumentElement();
        root.normalize();
        NodeList rootChildren = root.getChildNodes();
        for (int i=0; i < rootChildren.getLength(); i++) {
            NodeList subRootChildren = rootChildren.item(i).getChildNodes();
            if(subRootChildren.item(0).getTextContent().equalsIgnoreCase(fname)
                    && subRootChildren.item(1).getTextContent().equalsIgnoreCase(lname)){
                return false;
            }
            /*
            for(int j = 0; j < subRootChildren.getLength(); j++){
                PrintWriter out = response.getWriter();
                out.println(subRootChildren.item(j).getTextContent());
                //NodeList subSubRoot = subRootChildren.item(j).getChildNodes();
                /*
                if(subSubRoot.item(0).getTextContent().equalsIgnoreCase(fname)
                        && subSubRoot.item(1).getTextContent().equalsIgnoreCase(lname)){
                    return false;
                }
                */
                /*
                for(int k = 0; k < 2; k++){
                    if(subSubRoot.item(k).getTextContent().equalsIgnoreCase(fname)
                        && subSubRoot.item(k+1).getTextContent().equalsIgnoreCase(lname)){
                    return false;
                }
                }
            }*/
        }
        return true;
    }
    
    public void replaceValues(String fname, String lname, String[] plang, 
            String[] weekAvail, String[] dest, Document doc)
            throws IOException, TransformerConfigurationException,
            TransformerException{
        Element root = doc.getDocumentElement();
        root.normalize();
        NodeList rootChildren = root.getChildNodes();
        for (int i=0; i < rootChildren.getLength(); i++) {
            NodeList subRootChildren = rootChildren.item(i).getChildNodes();
            if(subRootChildren.item(0).getTextContent().equalsIgnoreCase(fname)
                    && subRootChildren.item(1).getTextContent().equalsIgnoreCase(lname)){
                if(plang.length > subRootChildren.item(2).getChildNodes().getLength()){
                    int x = plang.length - subRootChildren.item(2).getChildNodes().getLength();
                    for(int pl = 0; pl < x; pl++){
                        Element e = doc.createElement("PL");
                        Text textPlang = doc.createTextNode(plang[plang.length-pl-1]);
                        e.appendChild(textPlang);
                        subRootChildren.item(2).appendChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(2).getChildNodes().getLength(); a++){
                    subRootChildren.item(2).getChildNodes().item(a).setTextContent(plang[a]);
                }
                }
                else{
                    int x = subRootChildren.item(2).getChildNodes().getLength() - plang.length;
                    for(int pl = 0; pl < x; pl++){
                        Node e = subRootChildren.item(2).getChildNodes().item(x-pl-1);
                        subRootChildren.item(2).removeChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(2).getChildNodes().getLength(); a++){
                    subRootChildren.item(2).getChildNodes().item(a).setTextContent(plang[a]);
                }
                }
                /*
                for(int b = 0; b < weekAvail.length; b++){
                    subRootChildren.item(3).getChildNodes().item(b).setTextContent(weekAvail[b]);
                }
                */
                if(weekAvail.length > subRootChildren.item(3).getChildNodes().getLength()){
                    int x = weekAvail.length - subRootChildren.item(3).getChildNodes().getLength();
                    for(int wa = 0; wa < x; wa++){
                        Element e = doc.createElement("Day");
                        Text textWeek = doc.createTextNode(weekAvail[weekAvail.length-wa-1]);
                        e.appendChild(textWeek);
                        subRootChildren.item(3).appendChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(3).getChildNodes().getLength(); a++){
                    subRootChildren.item(3).getChildNodes().item(a).setTextContent(weekAvail[a]);
                }
                }
                else{
                    int x = subRootChildren.item(3).getChildNodes().getLength() - weekAvail.length;
                    for(int wa = 0; wa < x; wa++){
                        Node e = subRootChildren.item(3).getChildNodes().item(x-wa-1);
                        subRootChildren.item(3).removeChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(3).getChildNodes().getLength(); a++){
                    subRootChildren.item(3).getChildNodes().item(a).setTextContent(weekAvail[a]);
                }
                }
                if(dest.length > subRootChildren.item(4).getChildNodes().getLength()){
                    int x = dest.length - subRootChildren.item(4).getChildNodes().getLength();
                    for(int de = 0; de < x; de++){
                        Element e = doc.createElement("Destination");
                        Text textDest = doc.createTextNode(dest[dest.length-de-1]);
                        e.appendChild(textDest);
                        subRootChildren.item(4).appendChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(4).getChildNodes().getLength(); a++){
                    subRootChildren.item(4).getChildNodes().item(a).setTextContent(dest[a]);
                }
                }
                else{
                    int x = subRootChildren.item(4).getChildNodes().getLength() - dest.length;
                    for(int de = 0; de < x; de++){
                        Node e = subRootChildren.item(4).getChildNodes().item(x-de-1);
                        subRootChildren.item(4).removeChild(e);
                    }
                    for(int a = 0; a < subRootChildren.item(4).getChildNodes().getLength(); a++){
                    subRootChildren.item(4).getChildNodes().item(a).setTextContent(dest[a]);
                }
                }
                /*
                subRootChildren.item(2).setTextContent(str1);
                subRootChildren.item(3).setTextContent(str2);
                subRootChildren.item(4).setTextContent(str3);*/
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult("dataXML.xml");
		transformer.transform(source, result);
            }
        }
    }
}